# SPIDY AI — LEE Android starter

This is an early Android starter project for SPIDY AI, with LEE as the assistant nickname.

## Included in this starter
- Spider-neon style Android interface
- Hindi speech input using Android speech recognition and spoken replies
- Basic voice/text commands to open YouTube, Instagram, WhatsApp, Chrome, and Android Settings
- Web search command
- Call command opens the Android dialer for user confirmation; it does not place calls silently
- Optional HTTPS chat-backend endpoint setting (a backend is not included)
- GitHub Actions workflow to build a debug APK

## Important limitations
- This starter does **not** yet include a reliable always-on “LEE” wake-word engine. Android's standard speech recognizer is not a dedicated wake-word engine. Screen-off wake detection needs a separately integrated wake-word engine, microphone foreground service, permission handling, and device testing.
- It does not yet control every app or force every app into floating-window mode. Android and each app limit this; overlay/accessibility features require additional implementation and explicit permissions.
- Voice input relies on the speech services available on the device and may need internet. It does not guarantee speaker identity verification.
- Full AI chat needs a secure HTTPS backend. Never place private API keys in the Android app.

## Build APK from a phone using GitHub
1. Create a GitHub repository.
2. Upload the **contents** of this project folder, including the `.github/workflows/android-apk.yml` file and its folders.
3. Open the repository's **Actions** tab and select **Build SPIDY AI APK**.
4. Run the workflow with **Run workflow** if it did not start automatically.
5. Open the completed run and download the `SPIDY-AI-debug-APK` artifact. Extract it to get `app-debug.apk`.

The workflow builds a debug APK; it has not been built or device-tested as part of this archive.
