package com.spidy.ai

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.net.Uri
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var feed: LinearLayout
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var tts: TextToSpeech
    private val worker = Executors.newSingleThreadExecutor()
    private val bg = Color.rgb(8, 10, 22)
    private val panel = Color.rgb(20, 24, 43)
    private val neon = Color.rgb(0, 235, 190)
    private val white = Color.rgb(242, 246, 255)
    private val prefs by lazy { getSharedPreferences("spidy_settings", MODE_PRIVATE) }
    private val speechRequest = 501

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        addMessage("LEE", "Namaste! Main LEE hoon, SPIDY AI ki assistant. Mic dabao aur bolo: ‘LEE, YouTube kholo’ ya ‘LEE, Google par cricket search karo.’")
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 20, 18, 14)
            setBackgroundColor(bg)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val logo = TextView(this).apply {
            text = "🕷"
            textSize = 34f
            setTextColor(neon)
        }
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(10,0,0,0) }
        titles.addView(TextView(this).apply {
            text = "SPIDY AI  •  LEE"; textSize = 25f; setTextColor(neon); setTypeface(null, 1)
        })
        titles.addView(TextView(this).apply {
            text = "LEE VOICE ASSISTANT  •  HINDI + ENGLISH"; textSize = 10f; setTextColor(white)
        })
        header.addView(logo)
        header.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        val settings = Button(this).apply {
            text = "⚙"; setTextColor(neon); setBackgroundColor(panel)
            setOnClickListener { settingsDialog() }
        }
        header.addView(settings)
        root.addView(header)
        status = TextView(this).apply {
            text = "● READY"; setTextColor(neon); textSize = 12f
            setPadding(4, 14, 4, 12)
        }
        root.addView(status)
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(bg)
        }
        feed = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0,4,0,8) }
        scroll.addView(feed)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        }
        input = EditText(this).apply {
            hint = "Ask SPIDY anything…"
            setHintTextColor(Color.LTGRAY); setTextColor(white); textSize = 15f
            setSingleLine(true); imeOptions = EditorInfo.IME_ACTION_SEND
            setPadding(14, 4, 10, 4); setBackgroundColor(panel)
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_SEND) { sendInput(); true } else false
            }
        }
        val mic = Button(this).apply {
            text = "🎙"; setTextColor(neon); setBackgroundColor(panel)
            setOnClickListener { startListening() }
        }
        val send = Button(this).apply {
            text = "➤"; setTextColor(bg); setBackgroundColor(neon)
            setOnClickListener { sendInput() }
        }
        row.addView(input, LinearLayout.LayoutParams(0, 52, 1f))
        row.addView(mic, LinearLayout.LayoutParams(52, 52))
        row.addView(send, LinearLayout.LayoutParams(52, 52))
        root.addView(row)
        setContentView(root)
    }

    private fun addMessage(who: String, message: String) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 10, 14, 10)
            setBackgroundColor(panel)
        }
        card.addView(TextView(this).apply {
            text = who; textSize = 11f; setTextColor(neon); setTypeface(null, 1)
        })
        card.addView(TextView(this).apply {
            text = message; textSize = 15f; setTextColor(white); setPadding(0,5,0,0)
        })
        val lp = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 }
        feed.addView(card, lp)
    }

    private fun sendInput() {
        val message = input.text.toString().trim()
        if (message.isEmpty()) return
        input.setText("")
        addMessage("YOU", message)
        handleCommand(message)
    }

    private fun handleCommand(text: String) {
        val q = text.lowercase(Locale.ROOT)
        when {
            q.startsWith("search ") || q.startsWith("google ") || q.startsWith("search for ") -> {
                val query = text.substringAfter(" ").substringAfter("for ", text.substringAfter(" "))
                openSearch(query)
                reply("Searching the web for: $query")
            }
            q.contains("youtube") && (q.contains("open") || q.startsWith("youtube")) -> {
                openPackageOrSearch("com.google.android.youtube", "https://www.youtube.com")
                reply("YouTube kholne ki koshish kar raha hoon.")
            }
            q.contains("chrome") && q.contains("open") -> {
                openPackageOrSearch("com.android.chrome", "https://www.google.com")
                reply("Chrome kholne ki koshish kar raha hoon.")
            }
            (q.contains("whatsapp") && (q.contains("open") || q.contains("khol") || q.startsWith("whatsapp"))) -> {
                openPackageOrSearch("com.whatsapp", "https://www.whatsapp.com")
                reply("WhatsApp khol rahi hoon.")
            }
            (q.contains("instagram") && (q.contains("open") || q.contains("khol") || q.startsWith("instagram"))) -> {
                openPackageOrSearch("com.instagram.android", "https://www.instagram.com")
                reply("Instagram khol rahi hoon.")
            }
            (q.contains("youtube") && (q.contains("khol") || q.startsWith("youtube"))) -> {
                openPackageOrSearch("com.google.android.youtube", "https://www.youtube.com")
                reply("YouTube khol rahi hoon.")
            }
            (q.contains("call") || q.contains("phone lagao") || q.contains("dial karo") || q.contains("number milao")) -> {
                val digits = text.filter { it.isDigit() || it == '+' }
                if (digits.length >= 7) {
                    val dial = Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(digits)))
                    startActivity(dial)
                    reply("Dialer khol diya hai. Call karne se pehle number check karke call button dabao.")
                } else {
                    startActivity(Intent(Intent.ACTION_DIAL))
                    reply("Dialer khol diya hai. Contact ya number select kar lo.")
                }
            }
            q.contains("open settings") || q.contains("settings kholo") || q.contains("settings khol") -> {
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
                reply("Phone settings khol raha hoon.")
            }
            q == "help" || q.contains("what can you do") || q.contains("kya kar sakte") -> {
                reply("Try: 'LEE, YouTube kholo', 'Open Instagram', 'Open WhatsApp', 'call 9876543210', 'settings kholo', or 'Google par cricket news search karo'. Full AI chat ke liye secure backend URL configure karna hoga.")
            }
            else -> askAiBackend(text)
        }
    }

    private fun openPackageOrSearch(packageName: String, fallback: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) startActivity(launch) else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(fallback)))
    }

    private fun openSearch(query: String) {
        val uri = Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))
        startActivity(Intent(Intent.ACTION_VIEW, uri))
    }

    private fun reply(text: String) {
        addMessage("LEE", text)
        if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "spidy_reply")
    }

    private fun startListening() {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Bolo, LEE sun rahi hai…")
            }
            startActivityForResult(intent, speechRequest)
        } catch (_: Exception) {
            reply("Voice input available nahi hai. Phone mein Google speech service check karo.")
        }
    }

    @Deprecated("Deprecated by Android, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == speechRequest && resultCode == RESULT_OK) {
            val result = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!result.isNullOrBlank()) {
                input.setText(result)
                sendInput()
            }
        }
    }

    private fun settingsDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(24,8,24,0)
        }
        box.addView(TextView(this).apply {
            text = "Paste your own HTTPS AI backend URL. Do not put private API keys in the app."
            setTextColor(white)
        })
        val endpoint = EditText(this).apply {
            hint = "https://your-server.example/chat"
            setText(prefs.getString("endpoint", "") ?: "")
            setTextColor(white); setHintTextColor(Color.GRAY)
        }
        box.addView(endpoint)
        android.app.AlertDialog.Builder(this)
            .setTitle("SPIDY AI Settings")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                prefs.edit().putString("endpoint", endpoint.text.toString().trim()).apply()
                reply("LEE settings saved.")
            }.show().also { it.window?.setBackgroundDrawableResource(android.R.color.background_dark) }
    }

    private fun askAiBackend(prompt: String) {
        val endpoint = prefs.getString("endpoint", "") ?: ""
        if (endpoint.isBlank()) {
            reply("LEE ka AI chat backend abhi configure nahi hai. ⚙ Settings mein secure HTTPS chat backend ka URL add karo. Tab tak main app-opening aur web-search commands kar sakti hoon.")
            return
        }
        status.text = "● THINKING…"
        worker.execute {
            var answer = ""
            try {
                val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 30000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                val payload = JSONObject().put("message", prompt).toString()
                conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val body = stream.bufferedReader().use { it.readText() }
                val json = JSONObject(body)
                answer = json.optString("reply", "")
                if (answer.isBlank()) answer = "Backend response mein 'reply' field nahi mila. HTTP $code"
                conn.disconnect()
            } catch (e: Exception) {
                answer = "Backend connect nahi hua. URL aur server check karo. (${e.javaClass.simpleName})"
            }
            runOnUiThread {
                status.text = "● READY"
                reply(answer)
            }
        }
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts.language = Locale("hi", "IN")
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) tts.shutdown()
        worker.shutdownNow()
        super.onDestroy()
    }
}
